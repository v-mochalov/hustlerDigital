module.exports = require('browser-sync').create();
