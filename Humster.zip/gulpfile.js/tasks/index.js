require('./clean');
require('./copy');
require('./deploy');
require('./html');
require('./img');
require('./scripts');
require('./serve');
require('./styles');
require('./vendors');
require('./watch');

