$.gulp.task('serve', function() {
  $.bs.init({
    // proxy: 'bestcasino', // for PHP environment ç
    server: { baseDir: './' },
    notify: false
  });
});
