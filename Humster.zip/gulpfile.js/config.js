module.exports = {
    ftp: {
        host: '8.8.8.8',
        user: '_',
        password: '_',
        port: 21,
        dest: '/public_php/'
    },
};
