<?php

/* https://api.telegram.org/bot5346738974:AAECJLKoWFxG3ihVkcJvUAD6Iv5cLP6cnrg/getUpdates,
где, XXXXXXXXXXXXXXXXXXXXXXX - токен вашего бота, полученный ранее */

// $name = $_POST['user_name'];
// $phone = $_POST['user_interes'];
// $token = "5346738974:AAECJLKoWFxG3ihVkcJvUAD6Iv5cLP6cnrg";
// $chat_id = "-754848855";
// $arr = array(
//   'Имя пользователя: ' => $name,
//   'Телефон: ' => $phone,  
// );

// foreach($arr as $key => $value) {
//   $txt .= "<b>".$key."</b> ".$value."%0A";
// };

// $sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");

// if ($sendToTelegram) {
//   header('Location: thank-you.html');
// } else {
//   echo "Error";
// }
?>